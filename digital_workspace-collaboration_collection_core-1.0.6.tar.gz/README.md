# Ansible Collection - digital_workspace.collaboration_collection_core

This is a collection designed to facilitate Digital Workspace/Collaboration labs within the WWT platform.  

# Requirements
This collection was written and tested with the following versions of the required packages.
- Python 3.6+
- Python requests[socks]
- Ansible 2.9.18
- PyvCloud 20.1.0

The following variables are assumed to be present, and should be provided via the platform's webhooks. Depending on the module used will determine which ones are applicable. Please note that the platform sends the variables as **extra_vars**, which means those variables names take precedence.
- deployment_id (Automatic)
- deployment_uuid (Automatic)
- vapp_name (Automatic)
- vcd_catalog (User Defined)
- vcd_org (User Defined)
- vcd_vdc (User Defined)

# Platform Webhook Configuration
|Type|Method|URL|
|----|------|---|
|On Create|Post|https://atc-tower.wwtatc.com/api/v2/job_templates/{JobID}/launch/|

Body:
```json
{
  "extra_vars": {
    "deployment_id": "$deployment_id",
    "deployment_uuid": "$deployment_uuid",
    "vapp_name": "$vapp_vcloud_name",
    "vcd_catalog": "web-vApps",
    "vcd_org": "vCD-Prod",
    "vcd_vdc": "vCD-Prod-vApps",
    "vapp_ip": "$vapp_ip"
  }
}
```



# requirements.yml

In order to use this collection, it is necessary to import it. This may be accomplished in several different ways.

## Ansible Tower
If leveraging the ATC instance of Ansible Tower (AWX), the library has already been imported. In order to access this library, within your **./collections** folder, you must create and populate a **requirements.yml** file. 

````yml
---
collections:
  - digital_workspace.collaboration_collection_core
````

### Ansible Galaxy (Manual)
1. Download the .tar.gz file to the working/root directory of your project from the github repository.

1. Navigate to the working/root directory of your project via linux shell.

1. Import the collection
   ````
   # ansible-galaxy collection install digital_workspace-collaboration_collection_core-x.y.z.tar.gz
   ````

# Modules

## cisco_smart_license
Provides smart licensing registration automation for numerous device types. This module is written by WWT. This module provides the ability to do register supported devices with a Cisco Smart License Satellite Server. This library supports the use of a Socks5 Proxy if required. This is enabled through the use the **use_proxy** setting. When activating this option SOCKS5 traffic will be sent to **vapp_ip:1080**



### Supported Devices

The following devices are supported:

- Cisco Adaptive Security Appliance (1.3.2+)
- Cisco Expressway (x12.6+)
- Cisco Cloud Services Router 1000v (16.7+)
- Cisco Meeting Manager (3.0.1+)
- Cisco Emergency Responder (12.5+)
- Cisco Unified Communication Manager (12.0+)
- Cisco Unified Contact Center Express (12.5+)
- Cisco Unity Connection (12.5+)
  

Below are the ports that the supported devices use for their API's. These values are used when communicating directly with the supported device.
| Device Type         | Default API Port | API Port Configurable | Licensing URL                                   |
| ------------------- | ---------------- | --------------------- | ----------------------------------------------- |
| ASA                 | 443/TCP          | Yes                   | /Transportgateway/services/DeviceRequestHandler |
| Expressway          | 443/TCP          | No                    | /SmartTransport                                 |
| CSR1000v            | 443/TCP          | Yes                   | /SmartTransport                                 |
| CMM                 | 443/TCP          | No                    | /SmartTransport                                 |
| Emergency Responder | 443/TCP          | No                    | /Transportgateway/services/DeviceRequestHandler |
| CUCM                | 8443/TCP         | No                    | /Transportgateway/services/DeviceRequestHandler |
| UCCx                | 443/TCP          | No                    | /Transportgateway/services/DeviceRequestHandler |
| CUC                 | 443/TCP          | No                    | /Transportgateway/services/DeviceRequestHandler |

### Supported Parameters
|Parameter Name|Required|Default Value|Data Type|Description|
|---|---|---|---|---|
|vapp_ip|Yes|N/A|IP Address|IP Address which you will be directly connecting to|
|ssms_ip|Yes|N/A|IP Address|IP Address of the Cisco Smart Satellite Server that will provide licensing tokens|
|ssms_port|No|8443|Port Number|Port to use when making Smart Licensing token requests|
|api_port|Yes|N/A|Port Number|Port to connect to on end device.|
|ip_address|No|N/A|IP Address|Internal IP Address of end device (Only used when using a proxy)|
|username|Yes|N/A|string|Username on end device with admin permissions|
|password|Yes|N/A|string|Password on end device with admin permissions|
|token_description|No|N/A|string|Description of Smart License token|
|model|Yes|N/A|string|Type of device we are connecting to. Valid options include: ['asav','expressway','csr1kv','cucm','cuc',cmm', 'uccx', 'cer']|
|version|Yes|N/A|Floating Decimal|Version number of the endpoint, such as 12.5 for CUCM.|
|use_proxy|Yes|False|True\False|Will a SOCKS5 proxy be used|

### Product Specific Configuration

1. Copy REST API module to the ASAv (Filename will be something similar to **asa-restapi-7151-lfbff-k8.SPA**)
    ``` 
       ciscoasa# copy ftp://<IP-Address>/asa-restapi-7151-lfbff-k8.SPA disk0:
    ```

1. Configure Rest API binary
    ```
        ciscoasa(config)# rest-api image disk0:/asa-restapi-7151-lfbff-k8.SPA
    ```
    
1. Enable Rest API
   ```
       ciscoasa(config)# rest-api agent
   ```
   
1. Enable http(s) server on specified port (will use 443). This is how the Rest API's will be consumed.
   ```
       ciscoasa(config)# http server enable 443
   ```
1. Configure http(s) server access. Determine which interface the automation script will be accessing the ASA. In our example it will be done via the inside interface.
   ```
       ciscoasa(config)# http 0.0.0.0 0.0.0.0 inside
   ```
1. Configure DNS resolution. Smart Licensing requires lookup by DNS FQDN. In this example, we will be using the inside interface to connect to the DNS server at 192.168.10.10.
   ```
       ciscoasa(config)# dns name-server 192.168.10.10
       ciscoasa(config)# dns domain-lookup managment
   ```
1. Import Cisco Smart Licensing trust list. In newer versions of ASA code, this happens automatically.
   ```
       ciscoasa(config)# crypto ca trustpool import url http://www.cisco.com/security/pki/trs/ios_core.p7b
   ```
1. Import Cisco Smart Licensing Root certificate. The ASA must have a copy of the certificate chain for https communication to work
    ```
        ciscoasa(config)# crypto ca trustpoint CiscoLicensing
        ciscoasa(config-ca-trustpoint)# revocation-check none
        ciscoasa(config-ca-trustpoint)# entrollment terminal
        ciscoasa(config)# crypto ca authenticate CiscoLicensingCA
        -----BEGIN CERTIFICATE-----
	    MIIDITCCAgmgAwIBAgIBATANBgkqhkiG9w0BAQsFADAyMQ4wDAYDVQQKEwVDaXNj
	    bzEgMB4GA1UEAxMXQ2lzY28gTGljZW5zaW5nIFJvb3QgQ0EwHhcNMTMwNTMwMTk0
	    ODQ3WhcNMzgwNTMwMTk0ODQ3WjAyMQ4wDAYDVQQKEwVDaXNjbzEgMB4GA1UEAxMX
	    Q2lzY28gTGljZW5zaW5nIFJvb3QgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
	    ggEKAoIBAQCmvL2WEx4F9xRepyws1obmFyIuofHv9k3LtMeYISqhR8ZV2NeUcTgN
	    hxFEHhqvBxqcrmOIijjlIBw5TXhGLvI5xln3FbmMCllbu1y9DP6+o3AKi/fY8lbu
	    SqToDdtv0clgsf0Y/8aclm+miVeiYX3nEE/cX+opVqxzkKPrK1Q2rchHosXatVPr
	    aamlNVjp8+PAvSPPWL1xiGjmlJEg8yDnlI5x1647zITxBoTHS8jgD1ObpCtCxou3
	    x0eQlrTLLWLqL1Bdx7BipGgR2VvoJQ/EXV1fuI8n0ZHFXw12YfmkzT2ZIyeouwO9
	    Tm1waXy634vfX0NolRNeRN/Hxs8E3X/RAgMBAAGjQjBAMA4GA1UdDwEB/wQEAwIB
	    BjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBRJ3IVLPTHlGz5qF2Bq8zM9O0xz
	    6DANBgkqhkiG9w0BAQsFAAOCAQEAUH8k05MqZoYCXZ/oOK5cbU32sEljHHgkDakF
	    YE7c3v9P7St3/EYOzWNv291EaB46VnOrkJPTsWyePYvZiYe/5Ay9nhrsoMIhibtc
	    j6hWhs2YtkZVdbFGjfxmqEZ6PfRNVlcAat8PDc+DUBU8BP98Ieh4rBG6nNJVqSMs
	    fKe35sGvdPYVLpm3sfz5u+lz3n9b3euGxx47SRdlMItfsNoGuSr+f0lOip4HuFc3
	    86WL4RpIoinDfB5pOfCGeIDdzRbWus7K7rx8+YQoeHs1ICzcYORharYjzb0jDjr7
	    QYYWqUCT4ElNEKt1J+hvc5MuNbWIYv2uAnUVb3GbsvDWl99/KA==
	    -----END CERTIFICATE-----
	    quit
    ```

1. Import Cisco Smart Licensing Intermediate certificate.
   ```
       ciscoasa(config)# crypto ca trustpoint TGSSLCA
       ciscoasa(config-ca-trustpoint)# revocation-check none
       ciscoasa(config-ca-trustpoint)# enrollment terminal
       ciscoasa(config)# crypto ca authenticate TGSSLCA
       -----BEGIN CERTIFICATE-----
       MIIEZzCCA0+gAwIBAgIDD0JAMA0GCSqGSIb3DQEBCwUAMDIxDjAMBgNVBAoTBUNp
       c2NvMSAwHgYDVQQDExdDaXNjbyBMaWNlbnNpbmcgUm9vdCBDQTAeFw0xNTEwMDcy
       MDAxMTZaFw0zODA1MzAxOTQ4NDZaMDExCzAJBgNVBAYTAlVTMQ4wDAYDVQQKEwVD
       aXNjbzESMBAGA1UEAxMJVEcgU1NMIENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A
       MIIBCgKCAQEA2Ve9d84RotmKappGUGbKOm8o3dKG0nsLmZo69MiG0/jXpTLCKljM
       Uhaof5CWvmCcIPV3x2p2KIVZgH9NV1tG+w2lykfNxUzYJX8HmOxpaA9wedSe4W9m
       W120c1FpYMYi0xiJIq58XsYj1sFY75JUF6aAf5Sm+9t57Jz+eHzJOFsoahJptcvV
       57In3X5ZE3vm3nhcLi8vzTXFzJplPx96LzNb7vv44kuqWKiH798fQg3HZbyO652o
       zjvoNgtAQeBrPXEreFpV0dd/RIcIOE9UcPw/ujxWYOV1c7NuA0vc9R68n/APtqwW
       ieiUr5lpT+ncrH0gMZlQ0YD+LkqoPgD1AwIDAQABo4IBhTCCAYEwDgYDVR0PAQH/
       BAQDAgEGMBIGA1UdEwEB/wQIMAYBAf8CAQAwXAYDVR0gBFUwUzBRBgorBgEEAQkV
       AQUAMEMwQQYIKwYBBQUHAgEWNWh0dHA6Ly93d3cuY2lzY28uY29tL3NlY3VyaXR5
       L3BraS9wb2xpY2llcy9pbmRleC5odG1sMB0GA1UdDgQWBBTo2QM6QYRwHuuMPE5U
       E6QqMhN8QzBABgNVHR8EOTA3MDWgM6Axhi9odHRwOi8vd3d3LmNpc2NvLmNvbS9z
       ZWN1cml0eS9wa2kvY3JsL2NscmNhLmNybDB7BggrBgEFBQcBAQRvMG0wPQYIKwYB
       BQUHMAKGMWh0dHA6Ly93d3cuY2lzY28uY29tL3NlY3VyaXR5L3BraS9jZXJ0cy9j
       bHJjYS5jZXIwLAYIKwYBBQUHMAGGIGh0dHA6Ly9wa2ljdnMuY2lzY28uY29tL3Br
       aS9vY3NwMB8GA1UdIwQYMBaAFEnchUs9MeUbPmoXYGrzMz07THPoMA0GCSqGSIb3
       DQEBCwUAA4IBAQB/H+DSeH5AnxkzwRaPCq8lFCMh6A15JpHJtp52zt2dXaR/XUQ5
       ax7tg5Dt0enMjtTJl8G3+peuMIt9ypGqibWZrDaHNslV9P95LATm9+d0XhAHafIE
       ANE4eTpIDcJLl40doaxPRHuOnzR0N/2CWhZmfKVd4yzvdeLu3uzJbzCEJjzloEmF
       KchFzyiEQwqRRdhgNDoXoxh68pQo3OpYedIJq9CaW/vAf8vJPinbw9bq2jXhRge7
       txH7JWzwAWW5D2fLxJztyNpFc3izc/Wg6ocU3mErQO2EokbiZaFX2wPZalOjc17o
       Jibr2WSyUrkVbkMLF985hlpzMpeRqFJZKBLd
       -----END CERTIFICATE-----
       quit
   ```
   
1. Configure ASA to use Smart License Satellite.
    ```
       ciscoasa(config)# call-home
       ciscoasa(cfg-call-home)# profile License
       ciscoasa(cfg-call-home)# destination address http https://collab-ssms01.wwtlabs.local/Transportgateway/services/DeviceRequestHandler
    ```
    
1. Add the task to your Ansible Playlist
   ```yml
   task:
             - name: 'License ASA'
               cisco_smart_license:
                 vapp_ip: "{{ vapp_ip }}"
                 ssms_ip: "192.168.10.7"
                 ssms_port: 8443
                 api_port: 443
                 ip_address: "192.168.10.60"
                 username: "wwt"
                 password: "WWTwwt1!"
                 token_description: "License ASA"
                 model: "asav"
                 version: 12.7
                 use_proxy: True
   ```
   
#### Cisco Expressway
Please note the Cisco Expressway with Smart Licensing is not compatible with Microsoft Interop. Expressway must be configured for name resolution so that the FQDN of the Smart Licenisng server can be resolved. In most cases the server will be **collab-ssms01.wwtlabs.local**. 

1. Complete **Service Setup**.

1. Navigate to Maintenance -> Smart Licensing

1. Under **Transport** configure **Transport Settings** for **Cisco Smart Software Manager On-Prem**.

1. Under **Transport** configure **URL** as **https://\<Satellite Server FQDN>/SmartTransport\>**.

1. Add the task to your Ansible playbook.
   ```yml
   task:
             - name: 'License Expressway'
               cisco_smart_license:
                 vapp_ip: "{{ vapp_ip }}"
                 ssms_ip: "192.168.10.7"
                 ssms_port: 8443
                 api_port: 443
                 ip_address: "192.168.10.80"
                 username: "admin"
                 password: "WWTwwt1!"
                 token_description: "License Expressway 1"
                 model: "expressway"
                 version: 12.7
                 use_proxy: True
   ```

#### Cisco Cloud Service Router (CSR1000v) 

1. Enable Restconf API.
   ```
       router(config)# restconf
   ```
   
1. Configure http(s) server, which is how Restconf API is consumed. Default is port 443, but you may modify the port
   ```
       router(config)# ip http secure-port 443
       router(config)# ip http secure-server
   ```
   
1. Configure CSR1K to use Smart License Satellite
   ```
       router(config)# license smart url https://<Satellite Server FQDN>/SmartTransport
       router(config)# license smart transport smart
       router(config)# no license smart server-identity-check
       router(config)# crypto pki trustpoint SLA-TrustPoint
       router(config-crypto)# revocation-check none
       router(config)# platform hardware throughput level MB 100
       router(config)# license boot level ax
   ```
   
1. Add the task to your playlist.
   ```yml
   task:
             - name: 'License CSR1000v'
               cisco_smart_license:
                vapp_ip: "{{ vapp_ip }}"
                ssms_ip: "192.168.10.7"
                ssms_port: 8443
                api_port: 443
                ip_address: "192.168.10.1"
                username: "wwt"
                password: "WWTwwt1!"
                token_description: "CSR1K-1"
                model: "csr1k"
                version: 17.3
                use_proxy: True
   ```
   
#### Cisco Meeting Manager
1. Navigate to Settings -> Licensing.

1. Next to **\<Transport Settings>**, Select **\<Next>**.

1. Under **\<Transport Settings>**, configure the proper URL. The URL is **https://\<Satellite Server FQDN>/SmartTransport**.

1. Add the task to your Ansible playbook.
   ```yml
   task:
             - name: 'License CMM #1'
               cisco_smart_license:
                 vapp_ip: "{{ vapp_ip }}"
                 ssms_ip: "192.168.10.7"
                 ssms_port: 8443
                 api_port: 443
                 ip_address: "192.168.10.41"
                 username: "admin"
                 password: "WWTwwt1!"
                 token_description: "CMM #1"
                 model: "cmm"
                 version: 12.5
                 use_proxy: True
   ```

#### Cisco Emergency Responder
1. Navigate to System -> Licensing Manager

1. Next to **\<Transport Gateway>**, select **\<View/Edit>**.

1. Select **\<Transport Gateway>**, and configure the proper url **https://\<Satellite Server FQDN>/Transportgateway/services/DeviceRequestHandler**

1. Add the task to your Ansible playbook.
   ```yml
   task:
             - name: 'License CER'
               cisco_smart_license:
                 vapp_ip: "{{ vapp_ip }}"
                 ssms_ip: "192.168.10.7"
                 ssms_port: 8443
                 api_port: 443
                 ip_address: "192.168.10.50"
                 username: "administrator"
                 password: "WWTwwt1!"
                 token_description: "License ASA"
                 model: "cer"
                 version: 12.5
                 use_proxy: True
   ```

#### Cisco Unified Communication Manager

1. Add the task to your Ansible playbook.
   ```yml
   task:
             - name: 'License CUCM # 1'
               cisco_smart_license:
                 vapp_ip: "{{ vapp_ip }}"
                 ssms_ip: "192.168.10.7"
                 ssms_port: 8443
                 api_port: 8443
                 ip_address: "192.168.10.21"
                 username: "administrator"
                 password: "WWTwwt1!"
                 token_description: "CUCM #1"
                 model: "cucm"
                 version: 12.5
                 use_proxy: True
   ```

#### Cisco Unified Contact Center Express

1. Add the task to your Ansible playbook.
   ```yml
   task:
             - name: 'License UCCx #1'
               cisco_smart_license:
                 vapp_ip: "{{ vapp_ip }}"
                 ssms_ip: "192.168.10.7"
                 ssms_port: 8443
                 api_port: 443
                 ip_address: "192.168.10.35"
                 username: "administrator"
                 password: "WWTwwt1!"
                 token_description: "UCCx #1"
                 model: "uccx"
                 version: 12.5
                 use_proxy: True
   ```

#### Cisco Unity Connection

1. Add the task to your Ansible playbook.
   ```yml
   task:
             - name: 'License CUC # 1'
               cisco_smart_license:
                 vapp_ip: "{{ vapp_ip }}"
                 ssms_ip: "192.168.10.7"
                 ssms_port: 8443
                 api_port: 443
                 ip_address: "192.168.10.31"
                 username: "administrator"
                 password: "WWTwwt1!"
                 token_description: "CUC #1"
                 model: "cuc"
                 version: 12.5
                 use_proxy: True
   ```


## vcd_vapp_vm
Provides automation for performing vCloud functions. This specific module is designed to copy a VM from an existing vApp or vApp template. This module is written by VMware. If you intent is to create a copy of the Cisco Smart Satellite server, please consider using the **importssms** role.

### VMware vCloud Variables

Below are the recommended values depending on the vCloud environment that you are working in.

|vCloud Environment|vOrg|vDC|Catalog Name|
|---|---|---|---|
|Sandbox|vCD-Sand|vCD-Sand-vApps|vCD-Sand Templates|
|Portal|vCD-Prod|vCD-Prod-vApps|web-vApps|

### Insert VM from template into running vApp
This covers the use case of inserting VM in a template into a specific vApp.
````yml
       tasks:
          - include_vars: vCloud-vars.yml
          - debug: var=playbook_dir
          - name: Import VM from catalog
            vcd_vapp_vm:
                    user:  "{{ env_user }}"
                    password: "{{ env_password }}"
                    org: "{{ vcd_org }}"
                    host: "{{ env_host }}"
                    target_vdc: "{{ vcd_vdc }}"
                    source_catalog_name: "{{ vcd_catalog }}"
                    source_template_name: "{{ vapp_template_name }}"
                    source_vm_name: "{{ vm_name }}"
                    target_vapp: "{{ vapp_name }}"
                    target_vm_name: "{{ vm_name }}"
                    state: "present"
````

## vmware_view
Provides VMware View configuration automation. The key function of this module is to modify the VMware View external IP Address. This module is written by WWT.

### Supported Parameters
|Parameter Name|Required|Default Value|Data Type|Description|
|---|---|---|---|---|
|vapp_ip|Yes|N/A|IP Address|IP Address that provides direct connectivity to the UAG|
|restconf_port|No|9443|Port|Port number that the admin rest api listens to on the UAG|
|restconf_username|Yes|admin|String|Username with administration privledges on the UAG|
|restconf_password|Yes|WWTwwt1!|String|Password with administration privledges on the UAG|
|version|Yes|N/A|Float/Integer| Version of the UAG software that is running|

### Update Unified Access Gateway Configuration
This provides the ability to modify the Unified Access Gateway (UAG) edge's configuration. Specifically this function is related to updating the UAG's source address so packets are sent properly.
````yml
  tasks:
          - name: Update UAG Configuration
            vmware_view:
              vapp_ip: {{ vapp_ip_address }}
              restconf_port: {{ port }}
              restconf_username: "admin"
              restconf_password: "WWTwwt1!"
              version: 3.8
            register: abcd

          - name: Debugging
            debug: var=abcd
````

## wwt_platform
This module contains custom functions to integrate with the WWT Platform. Regarding the messages that are sent to the user, on the latest one is visible to the user. If you want to clear all messages, send a single space as the message body ' '.

### Supported Parameters
|Parameter Name|Required|Default Value|Data Type|Description|
|---|---|---|---|---|
|deployment_id|Yes|N/A|string||
|deployment_uuid|Yes|N/A|string||
|message|No|N/A|String|Text message to be sent to the user|
|external_status|No|N/A|String|Status of the deployment. Only setting it to 'active' will make the access links visible to the user|

### Set Deployment to Active so access links become visible

````yml
  task:
     - name: Activate Links
       wwt_platform:
         deployment_id: "{{ deployment_id }}"  <--- Passed in from platform as extra_vars
         deployment_uuid: "{{ deployment_uuid }}" <--- Passed in from platfrom as extra_vars
         external_status: 'active'
````

### Send status message to user
````yml
  tasks:
     - name: Send message to user
       wwt_platform:
         deployment_id: "{{ deployment_id }}"  <--- Passed in from platform as extra_vars
         deployment_uuid: "{{ deployment_uuid }}" <--- Passed in from platfrom as extra_vars
         message: 'Lab Provisioning Complete'
````

# Roles

## importssms

This role is designed to simplify the process of creating a clone of our Cisco Smart License Satellite Server (Collab-SSMS01). The assumption is that the vCloud parameters will be passed in via the platform webhook as an extra variable(s). Variables coming from the main.yml should not need to be adjusted.

### Supported Parameters
|Parameter Name|Location|Default Value|Data Type|Description|
|---|---|---|---|---|
|env_host|/role/importssms/main.yml|vcloud.wwtatc.local|string|FQDN of vCloud Front End|
|env_api_version| /role/importssms/main.yml |30.0|float|API Version|
|env_verify_ssl_ssl_certs|/role/importssms/main.yml|false|boolean|Require trusted SSL certificates|
|template_name| /role/importssms/main.yml |ps-collab-ssms01-012821|String|Name of source vApp Template|
|vm_name| /role/importssms/main.yml |Collab-SSMS01|String|Source VM|
|vcd_org| Passed in Variable        |N/A|String|vCloud Org Name|
|vcd_vdc| Passed in Variable        |N/A|String|vCloud vDC Name|
|vcd_catalog| Passed in Variable        |N/A|String|vCloud vApp Catalog Name|
|vapp_name| Passed in Variable        |N/A|String|vCloud Destination vApp Name|

### Copy Collab-SSMS01 into vApp
`````yml
  tasks:

    - name: Create Smart License VM
      include_role:
        name: digital_workspace.collaboration_collection_core.importssms
`````

